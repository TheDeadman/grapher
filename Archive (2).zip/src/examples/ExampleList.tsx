import {
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
} from "@mui/material";
import { useNavigate } from "react-router-dom";
export const ExampleList = () => {
  const navigate = useNavigate();
  const code =
    "import * as React from 'react';\nimport Box from '@mui/material/Box';\n\nexport default function BoxSx() {\n  return (\n    <Box\n      sx={{\n        width: 300,\n        height: 300,\n        backgroundColor: 'primary.dark',\n        '&:hover': {\n          backgroundColor: 'primary.main',\n          opacity: [0.9, 0.8, 0.7],\n        },\n      }}\n    />\n  );\n}\n";
  return (
    <List>
      <ListItem disablePadding>
        <ListItemButton onClick={() => navigate("/examples/basic")}>
          <ListItemText primary={"Basic Example"} />
        </ListItemButton>
      </ListItem>
    </List>
  );
};
