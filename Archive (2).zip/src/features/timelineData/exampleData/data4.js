let data = [
  {
    name: "HTML Read",
    entryType: "measure",
    startTime: 0,
    duration: 78.69999992847443,
  },
  {
    name: "ReactScriptParsedBeforeRender",
    entryType: "measure",
    startTime: 0,
    duration: 484,
  },
  { name: "app rendered", entryType: "measure", startTime: 0, duration: 641.5 },
];

export default data;
