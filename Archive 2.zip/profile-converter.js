const fs = require("fs");
const getFromMap = require("./src/lib/getFromMap");

let data2 = [];
// let data = fs.readFileSync("./white-screen-converted.json", { encoding: "utf-8" });
let data = fs.readFileSync("./white-screen.json", { encoding: "utf-8" });
// let data = fs.readFileSync("./test-profile.json", { encoding: "utf-8" });
data = JSON.parse(data);

async function go(data) {
  for (let i = 0; i < data.length; i++) {
    theObj = data[i]
    // Handle callframes
    if (theObj.callFrame) {
      console.log(theObj.callFrame)
        await rewriteStackTrace([theObj.callFrame]);
    }

    console.log(theObj)
    // Handle beginData
    if (theObj?.args?.beginData?.stackTrace) {
      await rewriteStackTrace(theObj?.args?.beginData?.stackTrace);
    }
    // Handle cpuProfile nodes
    if (theObj?.args?.data?.cpuProfile?.nodes) {
      console.log("\nhere")
      await rewriteStackTrace(theObj?.args?.data?.cpuProfile?.nodes);

        // for (let x = 0; x < theObj?.args?.data?.cpuProfile?.nodes.length; x++) {
        //   console.log("HERE")
        //   console.log(theObj?.args?.data?.cpuProfile?.nodes[x].callFrame)
        //     await rewriteStackTrace(theObj?.args?.data?.cpuProfile?.nodes[x].callFrame);
        // }
    } 
    // console.log("dataojbbefore", theObj?.args?.data?);

    if (theObj?.args?.data?.stackTrace) {
      await rewriteStackTrace(theObj?.args?.data?.stackTrace);
    } else if (theObj?.args?.data?.callFrame) {

    } else if (theObj?.args?.data?.url && theObj?.args?.data?.url.indexOf('https://planning.ehi.com/static/js/main.561829d4.js') !== -1) {
        let stackData = await getFromMap(
            theObj.args.data.url.replace("https://planning.ehi.com/static/js/", "") +
              ".map",
              theObj.args.data.lineNumber,
              theObj.args.data.columnNumber
          );
          theObj.args.data.url = stackData.source;
          theObj.args.data.lineNumber = stackData.line;
          theObj.args.data.columnNumber = stackData.column;
          theObj.args.data.functionName = stackData.name;
    }
    // console.log("dataojbafter", theObj?.args?.data?);
  }
  fs.writeFileSync("./white-screen-converted.json", JSON.stringify(data), {
    encoding: "utf-8",
  });
}

async function rewriteStackTrace(stackTrace) {
  for (let i = 0; i < stackTrace.length; i++) {
    let stackItem = stackTrace[i];
    console.log("stack trace", stackItem)
    if (stackItem.callFrame) {
      stackItem = stackItem.callFrame
    } 

    if (stackItem.url && stackItem.url.indexOf("https://planning.ehi.com/static/js/main.561829d4.js") !== -1) {
      // if (stackItem.url && stackItem.url.indexOf("https://planning.ehi.com/static/js/main.561829d4.js") !== -1 && stackItem.lineNumber >= 1) {
      console.log(stackItem)
      let stackData = await getFromMap(
        stackItem.url.replace("https://planning.ehi.com/static/js/", "") +
          ".map",
        stackItem.lineNumber < 2 ? 2 : stackItem.lineNumber,
        stackItem.columnNumber
      );
      console.log(stackData)
      stackItem.url = stackData.source;
      stackItem.lineNumber = stackData.line;
      stackItem.columnNumber = stackData.column;
      stackItem.functionName = stackData.name;
      //   console.log(stackData);
    } 
    // else if (stackItem.lineNumber < 2) {
    //   stackItem.url = "mainJSNotLine2"
    // }
  }
}

go(data);
// async function test() {
//   let data = await getFromMap("main.561829d4.js.map", 2, 479559);
//   console.log(data);
// }
// test();
