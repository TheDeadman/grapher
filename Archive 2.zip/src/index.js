const parseErrorText = require("./lib/errorParser");

function doIt(minifiedPath, errorString) {
  parseErrorText(minifiedPath, errorString);
}

module.exports = doIt;

// /src/testfiles/main.561829d4.js “Error!
// at main.561829d4.js:2:260566”

// Error: Test
//     at App.tsx:42:11
//     at Mu (react-dom.production.min.js:262:359)
//     at t.unstable_runWithPriority (scheduler.production.min.js:18:343)
//     at Go (react-dom.production.min.js:122:325)
//     at Zu (react-dom.production.min.js:261:308)
//     at react-dom.production.min.js:261:215
//     at L (scheduler.production.min.js:16:224)
//     at b.port1.onmessage (scheduler.production.min.js:12:346)

// "Error: Test
//   at main.561829d4.js:2:260566"

planning.ehi.com/static/js/main.561829d4.js:2:2575328

planning.ehi.com/static/js/main.561829d4.js:2:2576259





unminify ./src/test-files/ "Error: Test
 at main.561829d4.js:2:2576277
 unminify ./src/test-files/ "Error: Test
 at main.561829d4.js:2:2509975






unminify ./src/test-files/ "Error: Test
 at main.561829d4.js:2:2698384


unminify ./src/test-files/ "Error: Test
 at main.561829d4.js:2:325621

unminify ./src/test-files/ "Error: Test
 at main.561829d4.js:2:2499989

unminify ./src/test-files/ "Error: Test
 at main.561829d4.js:2:2488883

unminify ./src/test-files/ "Error: Test
 at main.561829d4.js:2:2531176

unminify ./src/test-files/ "Error: Test
 at main.561829d4.js:2:1649446


unminify ./src/test-files/ "Error: Test
 at main.561829d4.js:2:2698919

unminify ./src/test-files/ "Error: Test
 at main.561829d4.js:2:2663039

unminify ./src/test-files/ "Error: Test
 at main.561829d4.js:2:2698885


unminify ./src/test-files/ "Error: Test
 at main.561829d4.js:2:2501632

unminify ./src/test-files/ "Error: Test
 at main.561829d4.js:2:2522817

unminify ./src/test-files/ "Error: Test
 at main.561829d4.js:2:2602602

unminify ./src/test-files/ "Error: Test
 at main.561829d4.js:2:2522739

unminify ./src/test-files/ "Error: Test
 at main.561829d4.js:2:2522271

unminify ./src/test-files/ "Error: Test
 at main.561829d4.js:2:2510600

unminify ./src/test-files/ "Error: Test
 at main.561829d4.js:2:2509975


!!! PAINT?!?!

unminify ./src/test-files/ "Error: Test
 at main.561829d4.js:2:2522271

unminify ./src/test-files/ "Error: Test
 at main.561829d4.js:2:2510600

unminify ./src/test-files/ "Error: Test
 at main.561829d4.js:2:2509975

unminify ./src/test-files/ "Error: Test
 at main.561829d4.js:2:2510600

unminify ./src/test-files/ "Error: Test
 at main.561829d4.js:2:2509975

  ehiHeadersInterceptor... ehiBaseService

