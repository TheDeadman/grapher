import { useEffect, useMemo, useState } from "react";
import Timeline from "./timeline/Timeline";
import "./App.css";

import data from "./timeline/data";
import data2 from "./timeline/data2";
import data3 from "./timeline/data3";

import data4 from "./timeline/data4";
import data5 from "./timeline/data5";
import data6 from "./timeline/data6";
import { useDispatch } from "react-redux";
import { setTimelineEntries, setMaxTime } from "./timeline/timelineSlice";
import { TimelineList } from "./timeline/TimelineList";

const baseTime = 0;
// const baseTime = 520541;

function App() {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(
      setTimelineEntries({
        "Zebra Tablet": data,
        "Mac - Low End Device Mode": data2,
        Mac: data3,
      })
    );
  }, []);
  const [minTime, setMinTime] = useState(baseTime);
  const [compareMode, setCompareMode] = useState(false);

  useEffect(() => {
    performance.measure("app rendered");
  }, []);
  return (
    <div className="App">
      <div>
        <div>
          <label>Min Time: </label>
          <input
            type="number"
            id="fname"
            name="fname"
            onChange={(e) =>
              e.target.value
                ? dispatch(setMinTime(parseInt(e.target.value)))
                : 0
            }
          />
          &nbsp;&nbsp;&nbsp;
          <label>Max Time:</label>
          <input
            type="number"
            id="fname"
            name="fname"
            onChange={(e) =>
              e.target.value
                ? dispatch(setMaxTime(parseInt(e.target.value)))
                : 0
            }
          />
        </div>
        <div>
          <button onClick={() => setCompareMode(!compareMode)}>
            {!compareMode ? "Compare" : "List"}
          </button>

          <button
            onClick={() =>
              dispatch(
                setTimelineEntries({
                  "Zebra Tablet": data,
                  "Mac - Low End Device Mode": data2,
                  Mac: data3,
                })
              )
            }
          >
            Reset Max Time
          </button>
        </div>
      </div>

      {/* <TimelineList /> */}
    </div>
  );
}

export default App;
