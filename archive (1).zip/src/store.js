import { configureStore } from "@reduxjs/toolkit";
import timelineReducer from "./timeline/timelineSlice";

export const store = configureStore({
  reducer: {
    timeline: timelineReducer,
  },
});
