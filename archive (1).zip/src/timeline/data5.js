let data = [
  {
    name: "HTML Read",
    entryType: "measure",
    startTime: 0,
    duration: 156.20000004768372,
  },
  {
    name: "ReactScriptParsedBeforeRender",
    entryType: "measure",
    startTime: 0,
    duration: 333.2000000476837,
  },
  { name: "app rendered", entryType: "measure", startTime: 0, duration: 449.5 },
];

export default data;
