import { createSlice, createSelector } from "@reduxjs/toolkit";

const getMaxTime = (arr) => {
  let maxTime = 0;
  arr.forEach((entry) => {
    console.log(entry);
    const endTime = entry.startTime + entry.duration;
    if (endTime > maxTime) {
      maxTime = endTime;
    }
  });
  return maxTime;
};

const initialState = {
  data: {},
  maxTime: 0,
  secondWidthData: {
    width: 0,
    sections: 0,
    remainder: 0,
  },
  tooltipData: { text: "", left: 0, top: 0 },
};

export const timelineSlice = createSlice({
  name: "timeline",
  initialState,
  reducers: {
    setTimelineEntries: (state, action) => {
      state.data = action.payload;
      let entries = [];
      Object.entries(action.payload).forEach(([key, val]) => {
        console.log(key, val);
        entries = [...entries, ...val];
      });
      state.maxTime = getMaxTime(entries);
      state.secondWidthData = {
        width: 1000 / state.maxTime,
        sections: parseInt(state.maxTime / 1000),
        remainder: state.maxTime % 1000,
      };
    },
    setMaxTime: (state, action) => {
      state.maxTime = action.payload;
      state.secondWidthData = {
        width: 1000 / state.maxTime,
        sections: parseInt(state.maxTime / 1000),
        remainder: state.maxTime % 1000,
      };
    },
    setTimelineEntryByName: (state, action) => {
      state.data[action.payload.name] = action.payload.entries;
    },
    setTooltipData: (state, action) => {
      state.tooltipData = action.payload;
    },
  },
});

// Action creators are generated for each case reducer function
export const { setTimelineEntries, setTooltipData, setMaxTime } =
  timelineSlice.actions;

export const selectEntriesByName = (state, name) => state.data[name];
export const selectTooltipData = (state) => {
  console.log("Selecting tooltip data");
  return state.timeline.tooltipData;
};

export const selectEntryNames = (state) => {
  console.log("Selecting entry names", state);
  return Object.keys(state.timeline.data);

  //   return state.timeline.data;
  if (state && state.timeline) {
    return Object.keys(state.timeline.data);
  }
  return [];
};

// export const selectEntriesByName = createSelector(
//     [
//       // Usual first input - extract value from `state`
//       state => state.items,
//       // Take the second arg, `category`, and forward to the output selector
//       (state, category) => category
//     ],
//     // Output selector gets (`items, category)` as args
//     (items, category) => items.filter(item => item.category === category)
//   );

export default timelineSlice.reducer;
